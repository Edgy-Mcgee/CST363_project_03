package heapdb;

import java.util.ArrayList;

public class LSMindex {
	
	private class Entry {
		private Object key;
		private int blockNo;
		
		private Entry(Object k, int b) {
			key=k;
			blockNo=b;
		}
	}
	
	private ArrayList<Entry> entries = new ArrayList<>();
	
	public void append(Object key, int blockNo) {
		entries.add(new Entry(key, blockNo));
	}
	
	/*
	 * binary search of index array.
	 * return  -1 index is empty, or key is < lowest key value.
	 *        int blockNumber to search for tuple.
	 */
	public int lookup(Object key) {
		
		//TODO delete the following line
		return 0;
	}
	
	public void printDiagnostic() {
		 System.out.println("Begin index entries.");
		 for (Entry e: entries) {
			 System.out.printf("%d %d \n",e.key, e.blockNo);
		 }
		 System.out.println("End index entries.");
	}

}
